# Widen9ne

Static site. No build step — it's just `index.html` plus one image.

```
widen9ne-site/
├── index.html
└── assets/
    └── logo-white.png
```

## Push to GitHub

```bash
cd widen9ne-site
git init
git add .
git commit -m "Initial site"
git branch -M main
git remote add origin https://github.com/<your-username>/widen9ne-site.git
git push -u origin main
```

(Create the empty repo on GitHub first, or run `gh repo create widen9ne-site --public --source=. --push` if you have the GitHub CLI.)

## Deploy on Cloudflare Pages

1. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
2. Pick the `widen9ne-site` repo, authorize Cloudflare on GitHub if prompted.
3. Build settings — this is a static site, so:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `/`
4. Save and deploy. Cloudflare builds on every push to `main` from then on.
5. To use your own domain: Pages project → **Custom domains** → add `widen9ne.com` (and `www`), then update the DNS records Cloudflare gives you (if the domain's already on Cloudflare, this is usually just adding a CNAME and it's automatic).

## Making changes later

Edit `index.html` directly, commit, push — Cloudflare redeploys automatically. Colors, spacing, and section order are all in the single `<style>` block near the top of the file; content (headlines, service copy, contact info) is in the HTML body below it.

## Notes

- Fonts (Fraunces, Inter) load from Google Fonts via `<link>` tags in `<head>` — no local font files needed.
- The logo in the nav is `assets/logo-white.png`, a white-recolored version of your crest logo (the original is black-on-white, which would disappear against the dark header) — swap that file if you want a different treatment.
